import React from 'react';
import './App.scss';
import {Switch, Route, Redirect} from 'react-router-dom';
import Login from './components/Login/Login';
import MainRouting from './components/MainRouting/MainRouting';

function App() {
  return (
    <div className="App">
      <Switch>
        <Route path='/login' component={Login} />
        <Route path='/admin' component={MainRouting} />
        <Redirect from='/' to="login" />
        {/* <Redirect path='/' to='/index' /> */}
      </Switch>
    </div>
  );
}

export default App;
