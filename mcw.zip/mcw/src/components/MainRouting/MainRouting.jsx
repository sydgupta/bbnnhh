import React from 'react';
import { useRouteMatch, Switch, Route } from 'react-router-dom';
import Dashboard from '../Main/Dashboard/Dashboard';
import MainHeader from '../Main/MainHeader/MainHeader';
import Sidebar from '../Main/Sidebar/Sidebar';
import './MainRouting.scss';

const MainRouting = () => {
    const {path} = useRouteMatch();
    console.log('path: ', path);
    return(
        <div className="app-main">
            <div className="side-panel">
                <Sidebar />
            </div>

            <div className="main-wrapper">
                <div className="header">
                    <MainHeader />
                </div>
                <Switch>
                    <Route path={`${path}/dashboard`} component={Dashboard} exact />
                </Switch>
            </div>
        </div>
    );
}

export default MainRouting;