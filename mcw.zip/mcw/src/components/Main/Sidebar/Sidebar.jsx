import React from 'react';

const Sidebar = () => {
    return(
        <h1>Sidebar</h1>
    );
}   

export default Sidebar;