import React from 'react';
import './MainHeader.scss';

const MainHeader = () => {
    return (
        <header>
            <div className="search">
                <input type="text" placeholder="search"/>
            </div>

            <div className="header-info">
                <div className="language">

                </div>
                <div className="profile">

                </div>
                <div className="notifications">
                    
                </div>
            </div>
        </header>
    )
}

export default MainHeader;