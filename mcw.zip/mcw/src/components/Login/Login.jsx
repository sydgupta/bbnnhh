import React from 'react';
import './Login.scss';
import { useForm, Controller } from "react-hook-form";
import history from '../../history';
import formImg from '../../assets/images/form-img.png';
import TextField from '@material-ui/core/TextField';
import MCWButton from '../../shared-components/Button/MCWButton';

const Login = ()=> {
    const { handleSubmit, errors, control, formState } = useForm({mode: "onChange"});
    const onSubmit = data => {
        history.push('/admin/dashboard');
    };
    console.log('Errors: ', errors);
    return(
        <div className="login-container">
            <div className="form">
                <div className="img">
                    <img src={formImg} alt=""/>
                </div>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <h3>Login</h3>
                    <p>Welcome back, please login to your account</p>
                    <div className="input-div">
                        <Controller 
                            as={TextField} 
                            control={control} 
                            label="Email" 
                            variant="outlined" 
                            size="small" 
                            rules={{ required: true }} 
                            name="email" 
                            defaultValue=""
                        />
                        {errors.email && <span className="error-msg">Email is required</span>}
                    </div>

                    <div className="input-div">
                        <Controller 
                            as={TextField} 
                            control={control} 
                            label="Password" 
                            variant="outlined" 
                            size="small" 
                            rules={{ required: true }} 
                            type="password" 
                            name="password" 
                            defaultValue=""
                        />
                        {errors.password && <span className="error-msg">Password is required</span>}
                    </div>   

                    <div className="forgot-pass">
                        <span>Forgot Password?</span>
                    </div>

                    <MCWButton variant="contained" color="primary" size="large" type="submit" disabled={!formState.isValid}>Login</MCWButton>
                </form>
            </div>
        </div>
    )
}

export default Login;