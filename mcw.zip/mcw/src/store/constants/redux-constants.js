
const constants = {
    LOGIN: 'LOGIN'
}

export default constants;