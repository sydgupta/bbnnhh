const initialState = {};

const userReducer = (state = initialState, action) => {
    return state;
};

export default userReducer;