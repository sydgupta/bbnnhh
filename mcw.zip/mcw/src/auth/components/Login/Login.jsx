import React from 'react';

const Login = () => {
    return (
        <h1>Login Page</h1>
    )
}

export default Login;