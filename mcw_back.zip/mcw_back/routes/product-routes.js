const express = require('express');
const router = express.Router();
const db = require('../config/db');
const verifyToken = require('../config/verify-token');

router.get('/getAll', verifyToken, (req, res, next) => {
    res.send({data: 'all products'});
})

module.exports = router;