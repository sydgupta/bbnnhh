const keys = {
    accessKey: 'ключ к mcw', // Russian
    refreshKey: 'atualizar a chave para mcw' // Portugese
}
module.exports = keys;